Por: Ricardo Manuel Lazo Vásquez


## Practica 2

Tuve problemas para compilar, aun sigo luchando con eso.
