Por: Ricardo Manuel Lazo Vásquez


## Practica 2

Tras corregirlo para que esté en C encontre problemas al momento de ejecutar el programa, parece que es mi version de flex, probe con varias opciones y resultó ser lo mismo en todos los casos.

Código por RW - Github

