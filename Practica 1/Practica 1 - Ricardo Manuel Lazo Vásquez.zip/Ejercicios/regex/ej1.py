from funs import *

def main():
    t = input()
    print(ej1(t))

if __name__ == "__main__":
    main()
