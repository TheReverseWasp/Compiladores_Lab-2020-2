from funs import *

def main():
    t = input()
    print(ej2(t))

if __name__ == "__main__":
    main()
