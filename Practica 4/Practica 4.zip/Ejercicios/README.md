# Practica 4

Ejecutar "python3 main.py" sin las comillas para probar la ejecución

Demo: https://youtu.be/uu1rjFrD6Ig

GitHub: https://github.com/TheReverseWasp/Compiladores_Lab-2020-2
