#Codigo por Ricardo Lazo Vásquez - ricardo.lazo@ucsp.edu.pe
#correspondiente al primer problema de la practica 0

from cf import *

def main():
    s = input()
    print(ej1(s))

if __name__ == "__main__":
    main()
