#Codigo por Ricardo Lazo Vásquez - ricardo.lazo@ucsp.edu.pe
#correspondiente al segundo problema de la practica 0

from cf import *

def main():
    s = input()
    print(ej2(s))


if __name__ == "__main__":
    main()
